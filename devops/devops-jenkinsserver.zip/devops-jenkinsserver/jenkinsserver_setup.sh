#!/bin/sh

#This script covers Step 3 to 17 of Jenkins Server Setip for DevOps LAB.
echo "----------------------------------------------------------------------------"
echo "This Script automates Step 3 to 17 of Jenkins Server Setip for DevOps LAB."
echo "----------------------------------------------------------------------------"
echo "Step-1: Installing GIT Client and Java"
sudo yum install git java-1.7.0-openjdk-devel.x86_64 -y
echo ""
echo ""
echo "Step-2: Installing Apache Maven"
sudo wget http://repos.fedorapeople.org/repos/dchen/apache-maven/epel-apache-maven.repo -O /etc/yum.repos.d/epel-apache-maven.repo 
sudo yum install apache-maven -y
echo ""
echo ""
echo "Step-3: Installing Jenkins"
sudo wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat/jenkins.repo
sudo rpm --import https://pkg.jenkins.io/redhat/jenkins.io.key
sudo yum install jenkins -y
sudo chkconfig jenkins on
sudo service jenkins start
echo ""
echo ""
echo "Step-4: Installing Docker"
sudo yum install -y docker
sudo service docker start
sudo chkconfig docker on
sudo usermod -aG dockerroot jenkins ; sudo usermod -aG dockerroot wfuser
sudo groupadd docker
sudo usermod -aG docker jenkins ; sudo usermod -aG docker wfuser
sudo service docker restart
echo "----------------------------------------------------------------------------"
echo "Completed Step 3 to 17 of Jenkins Server Setip for DevOps LAB."
echo "----------------------------------------------------------------------------"
